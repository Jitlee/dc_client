Vue.component('dc-home', {
	template: '#home-template',
	data() {
		return {
		}
	},
	created() {
	},
	methods: {
	}
});