Vue.component('dc-done', {
	template: '#done-template',
	data() {
		return {
		}
	},
	created() {
//		setTimeout(() => { this.$emit('close') }, 3000)
	},
	mounted() {
		
	},
	methods: {
	},
	computed: {
	}
})